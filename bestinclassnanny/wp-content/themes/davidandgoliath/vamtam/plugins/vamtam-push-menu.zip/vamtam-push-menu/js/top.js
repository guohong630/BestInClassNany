(function($, undefined) {
	"use strict";

	if(!Modernizr.csstransforms3d) return;

	var PM = {
		Models: {},
		Collections: {},
		Views: {}
	};
